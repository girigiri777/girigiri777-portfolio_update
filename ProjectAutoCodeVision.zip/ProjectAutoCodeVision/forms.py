from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import StringField, PasswordField, SubmitField, TextAreaField
from wtforms.validators import DataRequired, Email, Length, EqualTo, Regexp, ValidationError

class RegisterForm(FlaskForm):
    name = StringField('Full Name', validators=[
        DataRequired(message='Name is required'),
        Length(min=3, max=50, message='Name must be between 3 and 50 characters')
    ])
    
    email = StringField('Email Address', validators=[
        DataRequired(message='Email is required'),
        
        Email(message='Invalid email address'),
        Regexp(r'^[\w\.-]+@[\w\.-]+\.\w+$', message='Invalid email format')
    ])
    
    mobile = StringField('Mobile Number', validators=[
        DataRequired(message='Mobile number is required'),
        Regexp(r'^[6-9]\d{9}$', message='Mobile must be 10 digits and start with 6-9')
    ])
    
    password = PasswordField('Password', validators=[
        DataRequired(message='Password is required'),
        Regexp(
            r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$',
            message='Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 digit, and 1 special character (@$!%*?&)'
        )
    ])
    
    confirm = PasswordField('Confirm Password', validators=[
        DataRequired(message='Please confirm your password'),
        EqualTo('password', message='Passwords must match')
    ])
    
    submit = SubmitField('Register')

class LoginForm(FlaskForm):
    email = StringField('Email Address', validators=[
        DataRequired(message='Email is required'),
        Email(message='Invalid email address')
    ])
    
    password = PasswordField('Password', validators=[
        DataRequired(message='Password is required')
    ])
    
    submit = SubmitField('Login')

class AdminLoginForm(FlaskForm):
    email = StringField('Admin Email', validators=[
        DataRequired(message='Email is required'),
        Email(message='Invalid email address')
    ])
    
    password = PasswordField('Password', validators=[
        DataRequired(message='Password is required')
    ])
    
    submit = SubmitField('Login as Admin')

class UploadForm(FlaskForm):
    mockup_image = FileField('Upload Mockup Image', validators=[
        DataRequired(message='Please select an image'),
        FileAllowed(['jpg', 'jpeg', 'png'], message='Only JPG, JPEG, and PNG images are allowed')
    ])
    
    submit = SubmitField('Generate HTML/CSS')

class DatasetUploadForm(FlaskForm):
    dataset_name = StringField('Dataset Name', validators=[
        DataRequired(message='Dataset name is required'),
        Length(min=3, max=100, message='Dataset name must be between 3 and 100 characters')
    ])
    
    dataset_file = FileField('Upload Dataset (ZIP)', validators=[
        DataRequired(message='Please select a dataset file'),
        FileAllowed(['zip'], message='Only ZIP files are allowed')
    ])
    
    submit = SubmitField('Upload Dataset')
