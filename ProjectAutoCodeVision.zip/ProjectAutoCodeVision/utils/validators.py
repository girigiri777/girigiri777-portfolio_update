import re
from models import User

def validate_unique_email(email):
    user = User.query.filter_by(email=email).first()
    return user is None

def validate_unique_mobile(mobile):
    user = User.query.filter_by(mobile=mobile).first()
    return user is None

def validate_email_format(email):
    pattern = r'^[\w\.-]+@[\w\.-]+\.\w+$'
    return re.match(pattern, email) is not None

def validate_mobile_format(mobile):
    pattern = r'^[6-9]\d{9}$'
    return re.match(pattern, mobile) is not None

def validate_password_strength(password):
    pattern = r'^(?=.*[A-Z])(?=.*[a-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$'
    return re.match(pattern, password) is not None

def get_validation_errors(name, email, mobile, password, confirm_password):
    errors = []
    
    if len(name) < 3 or len(name) > 50:
        errors.append('Name must be between 3 and 50 characters')
    
    if not validate_email_format(email):
        errors.append('Invalid email format')
    elif not validate_unique_email(email):
        errors.append('Email is already registered')
    
    if not validate_mobile_format(mobile):
        errors.append('Mobile must be 10 digits and start with 6-9')
    elif not validate_unique_mobile(mobile):
        errors.append('Mobile number is already registered')
    
    if not validate_password_strength(password):
        errors.append('Password must be at least 8 characters with 1 uppercase, 1 lowercase, 1 digit, and 1 special character')
    
    if password != confirm_password:
        errors.append('Passwords do not match')
    
    return errors
