import cv2
import numpy as np
from PIL import Image

def preprocess_image(image_path):
    try:
        img = cv2.imread(image_path)
        if img is None:
            print(f'Error preprocessing image: Could not read image file')
            return {
                'components': [],
                'image_width': 1200,
                'image_height': 800
            }
        
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        
        edges = cv2.Canny(blurred, 50, 150)
        
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        components = []
        for contour in contours:
            x, y, w, h = cv2.boundingRect(contour)
            if w > 20 and h > 20:
                component = {
                    'type': classify_component(w, h),
                    'x': int(x),
                    'y': int(y),
                    'width': int(w),
                    'height': int(h)
                }
                components.append(component)
        
        components.sort(key=lambda c: (c['y'], c['x']))
        
        return {
            'components': components,
            'image_width': img.shape[1],
            'image_height': img.shape[0]
        }
    
    except Exception as e:
        print(f'Error preprocessing image: {str(e)}')
        return {
            'components': [],
            'image_width': 1200,
            'image_height': 800
        }

def classify_component(width, height):
    aspect_ratio = width / height if height > 0 else 1
    area = width * height
    
    if aspect_ratio > 5 and height < 50:
        return 'text_input'
    elif aspect_ratio < 2 and area < 5000:
        return 'button'
    elif aspect_ratio > 3 and area > 10000:
        return 'navbar'
    elif aspect_ratio < 1.5 and area > 20000:
        return 'container'
    elif aspect_ratio > 2 and height > 100:
        return 'header'
    elif aspect_ratio > 1 and aspect_ratio < 3:
        return 'card'
    else:
        return 'div'

def extract_features(components):
    features = []
    for comp in components:
        feature_vector = [
            comp['x'],
            comp['y'],
            comp['width'],
            comp['height'],
            comp['width'] / comp['height'] if comp['height'] > 0 else 1,
            comp['width'] * comp['height']
        ]
        features.append(feature_vector)
    return np.array(features)
