from werkzeug.security import generate_password_hash
from models import Admin, db

def seed_admin():
    try:
        existing_admin = Admin.query.filter_by(email='admin@autocodevision.com').first()
        if not existing_admin:
            admin = Admin(
                email='admin@autocodevision.com',
                password_hash=generate_password_hash('Admin@123')
            )
            db.session.add(admin)
            db.session.commit()
            print('✅ Admin account created successfully')
            return True
        else:
            print('ℹ️  Admin account already exists')
            return False
    except Exception as e:
        print(f'❌ Error seeding admin: {str(e)}')
        db.session.rollback()
        return False
