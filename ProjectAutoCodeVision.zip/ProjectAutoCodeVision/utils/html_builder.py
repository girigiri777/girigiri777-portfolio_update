def generate_html_css(components_data):
    if not components_data or 'components' not in components_data:
        return generate_default_html_css()
    
    components = components_data['components']
    
    if not components or len(components) == 0:
        return generate_default_html_css()
    
    image_width = components_data.get('image_width', 1200)
    image_height = components_data.get('image_height', 800)
    
    html_parts = []
    css_parts = []
    
    css_parts.append("""* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    background-color: #F8F9FA;
    color: #264653;
    padding: 20px;
}

.container {
    max-width: 1200px;
    margin: 0 auto;
    position: relative;
}
""")
    
    for idx, comp in enumerate(components):
        comp_type = comp.get('type', 'div')
        x = comp.get('x', 0)
        y = comp.get('y', 0)
        width = comp.get('width', 100)
        height = comp.get('height', 50)
        
        class_name = f'{comp_type}_{idx}'
        
        if comp_type == 'text_input':
            html_parts.append(f'    <input type="text" class="{class_name}" placeholder="Enter text">')
            css_parts.append(f""".{class_name} {{
    position: absolute;
    left: {x}px;
    top: {y}px;
    width: {width}px;
    height: {height}px;
    padding: 10px;
    border: 2px solid #0E7490;
    border-radius: 5px;
    font-size: 14px;
}}
""")
        
        elif comp_type == 'button':
            html_parts.append(f'    <button class="{class_name}">Click Me</button>')
            css_parts.append(f""".{class_name} {{
    position: absolute;
    left: {x}px;
    top: {y}px;
    width: {width}px;
    height: {height}px;
    background-color: #0E7490;
    color: white;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.3s;
}}

.{class_name}:hover {{
    background-color: #F4A261;
}}
""")
        
        elif comp_type == 'navbar':
            html_parts.append(f'    <nav class="{class_name}">')
            html_parts.append(f'        <a href="#">Home</a>')
            html_parts.append(f'        <a href="#">About</a>')
            html_parts.append(f'        <a href="#">Contact</a>')
            html_parts.append(f'    </nav>')
            css_parts.append(f""".{class_name} {{
    position: absolute;
    left: {x}px;
    top: {y}px;
    width: {width}px;
    height: {height}px;
    background-color: #0E7490;
    display: flex;
    align-items: center;
    gap: 20px;
    padding: 0 30px;
}}

.{class_name} a {{
    color: white;
    text-decoration: none;
    font-weight: 500;
    transition: color 0.3s;
}}

.{class_name} a:hover {{
    color: #E9C46A;
}}
""")
        
        elif comp_type == 'header':
            html_parts.append(f'    <h1 class="{class_name}">Page Header</h1>')
            css_parts.append(f""".{class_name} {{
    position: absolute;
    left: {x}px;
    top: {y}px;
    width: {width}px;
    height: {height}px;
    font-size: 32px;
    font-weight: 700;
    color: #0E7490;
    display: flex;
    align-items: center;
}}
""")
        
        elif comp_type == 'card':
            html_parts.append(f'    <div class="{class_name}">')
            html_parts.append(f'        <h3>Card Title</h3>')
            html_parts.append(f'        <p>Card content goes here</p>')
            html_parts.append(f'    </div>')
            css_parts.append(f""".{class_name} {{
    position: absolute;
    left: {x}px;
    top: {y}px;
    width: {width}px;
    height: {height}px;
    background-color: white;
    border: 1px solid #E9C46A;
    border-radius: 8px;
    padding: 20px;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}}

.{class_name} h3 {{
    color: #0E7490;
    margin-bottom: 10px;
}}

.{class_name} p {{
    color: #264653;
    line-height: 1.6;
}}
""")
        
        elif comp_type == 'container':
            html_parts.append(f'    <div class="{class_name}">')
            html_parts.append(f'        <p>Container content</p>')
            html_parts.append(f'    </div>')
            css_parts.append(f""".{class_name} {{
    position: absolute;
    left: {x}px;
    top: {y}px;
    width: {width}px;
    height: {height}px;
    background-color: white;
    border: 2px solid #F4A261;
    border-radius: 8px;
    padding: 20px;
}}
""")
        
        else:
            html_parts.append(f'    <div class="{class_name}"></div>')
            css_parts.append(f""".{class_name} {{
    position: absolute;
    left: {x}px;
    top: {y}px;
    width: {width}px;
    height: {height}px;
    background-color: #F8F9FA;
    border: 1px solid #0E7490;
    border-radius: 5px;
}}
""")
    
    html = '<!DOCTYPE html>\n<html lang="en">\n<head>\n    <meta charset="UTF-8">\n    <meta name="viewport" content="width=device-width, initial-scale=1.0">\n    <title>Generated UI</title>\n    <link rel="stylesheet" href="styles.css">\n</head>\n<body>\n<div class="container">\n'
    html += '\n'.join(html_parts)
    html += '\n</div>\n</body>\n</html>'
    
    css = '\n'.join(css_parts)
    
    return html, css

def generate_default_html_css():
    html = """<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sample UI</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<div class="container">
    <h1 class="header">Welcome to AutoCodeVision</h1>
    <p class="text">Your mockup has been processed successfully!</p>
    <button class="btn">Get Started</button>
</div>
</body>
</html>"""
    
    css = """* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background-color: #F8F9FA;
    color: #264653;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

.container {
    text-align: center;
    max-width: 600px;
    padding: 40px;
}

.header {
    font-size: 36px;
    color: #0E7490;
    margin-bottom: 20px;
}

.text {
    font-size: 18px;
    color: #264653;
    margin-bottom: 30px;
}

.btn {
    background-color: #0E7490;
    color: white;
    padding: 12px 30px;
    border: none;
    border-radius: 5px;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: background-color 0.3s;
}

.btn:hover {
    background-color: #F4A261;
}"""
    
    return html, css
