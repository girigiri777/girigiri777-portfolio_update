from flask import Flask, redirect, url_for
from flask_login import LoginManager
from models import db, User, Admin
from routes.user_routes import user_bp
from routes.admin_routes import admin_bp
from routes.predict_routes import predict_bp
from routes.dataset_routes import dataset_bp
from utils.seed_data import seed_admin
from utils.train_model import initialize_model
import os

app = Flask(__name__)

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
DATABASE_PATH = os.path.join(BASE_DIR, 'instance', 'local.db')

app.config['SECRET_KEY'] = os.environ.get('SESSION_SECRET', 'dev-secret-key-change-in-production')
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{DATABASE_PATH}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

db.init_app(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'user.login'

@login_manager.user_loader
def load_user(user_id):
    if user_id.startswith('admin_'):
        admin_id = int(user_id.replace('admin_', ''))
        return Admin.query.get(admin_id)
    elif user_id.startswith('user_'):
        uid = int(user_id.replace('user_', ''))
        return User.query.get(uid)
    return None

app.register_blueprint(user_bp)
app.register_blueprint(admin_bp)
app.register_blueprint(predict_bp)
app.register_blueprint(dataset_bp)

@app.route('/')
def index():
    return redirect(url_for('user.home'))

with app.app_context():
    os.makedirs('instance', exist_ok=True)
    os.makedirs('static/uploads', exist_ok=True)
    os.makedirs('dataset/uploads', exist_ok=True)
    os.makedirs('dataset/built_in/sketch_samples', exist_ok=True)
    os.makedirs('model', exist_ok=True)
    
    db.create_all()
    print('✅ Database tables created successfully')
    
    seed_admin()
    
    initialize_model()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
