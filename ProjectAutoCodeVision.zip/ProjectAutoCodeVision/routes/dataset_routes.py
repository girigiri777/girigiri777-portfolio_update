from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from models import Dataset, db
from forms import DatasetUploadForm
from utils.train_model import train_model_with_dataset
import os

dataset_bp = Blueprint('dataset', __name__, url_prefix='/dataset')

ALLOWED_EXTENSIONS = {'zip'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@dataset_bp.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if hasattr(current_user, 'name'):
        flash('Access denied. Admin only.', 'danger')
        return redirect(url_for('user.home'))
    
    form = DatasetUploadForm()
    
    if form.validate_on_submit():
        file = form.dataset_file.data
        dataset_name = form.dataset_name.data.strip()
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            timestamp = int(os.times().elapsed * 1000)
            unique_filename = f"{timestamp}_{filename}"
            
            upload_folder = 'dataset/uploads'
            os.makedirs(upload_folder, exist_ok=True)
            
            filepath = os.path.join(upload_folder, unique_filename)
            file.save(filepath)
            
            try:
                dataset = Dataset(
                    name=dataset_name,
                    uploaded_by=current_user.email,
                    file_path=filepath
                )
                db.session.add(dataset)
                db.session.commit()
                
                flash(f'Dataset "{dataset_name}" uploaded successfully!', 'success')
                return redirect(url_for('dataset.train', dataset_id=dataset.id))
            
            except Exception as e:
                db.session.rollback()
                flash(f'Error uploading dataset: {str(e)}', 'danger')
                if os.path.exists(filepath):
                    os.remove(filepath)
        else:
            flash('Invalid file type. Please upload ZIP files only.', 'danger')
    
    return render_template('dataset_upload.html', form=form)

@dataset_bp.route('/train/<int:dataset_id>')
@login_required
def train(dataset_id):
    if hasattr(current_user, 'name'):
        flash('Access denied. Admin only.', 'danger')
        return redirect(url_for('user.home'))
    
    dataset = Dataset.query.get_or_404(dataset_id)
    
    try:
        success, message = train_model_with_dataset(dataset.file_path)
        
        if success:
            flash(message, 'success')
        else:
            flash(message, 'warning')
    
    except Exception as e:
        flash(f'Training error: {str(e)}', 'danger')
    
    return redirect(url_for('admin.dashboard'))

@dataset_bp.route('/list')
@login_required
def list_datasets():
    if hasattr(current_user, 'name'):
        flash('Access denied. Admin only.', 'danger')
        return redirect(url_for('user.home'))
    
    datasets = Dataset.query.order_by(Dataset.upload_date.desc()).all()
    return render_template('dataset_list.html', datasets=datasets)
