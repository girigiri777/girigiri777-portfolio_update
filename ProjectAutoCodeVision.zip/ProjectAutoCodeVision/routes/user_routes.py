from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import User, Mockup, db
from forms import RegisterForm, LoginForm
from utils.validators import get_validation_errors

user_bp = Blueprint('user', __name__)

@user_bp.route('/')
def home():
    return render_template('home.html')

@user_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated and hasattr(current_user, 'name'):
        return redirect(url_for('user.dashboard'))
    
    form = RegisterForm()
    
    if form.validate_on_submit():
        name = form.name.data.strip()
        email = form.email.data.strip().lower()
        mobile = form.mobile.data.strip()
        password = form.password.data
        
        existing_email = User.query.filter_by(email=email).first()
        if existing_email:
            flash('Email is already registered', 'danger')
            return render_template('register.html', form=form)
        
        existing_mobile = User.query.filter_by(mobile=mobile).first()
        if existing_mobile:
            flash('Mobile number is already registered', 'danger')
            return render_template('register.html', form=form)
        
        try:
            new_user = User(
                name=name,
                email=email,
                mobile=mobile,
                password_hash=generate_password_hash(password)
            )
            db.session.add(new_user)
            db.session.commit()
            
            flash('Registration successful! Please log in.', 'success')
            return redirect(url_for('user.login'))
        
        except Exception as e:
            db.session.rollback()
            flash('Registration failed. Please try again.', 'danger')
            return render_template('register.html', form=form)
    
    if form.errors:
        for field, errors in form.errors.items():
            for error in errors:
                flash(error, 'danger')
    
    return render_template('register.html', form=form)

@user_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated and hasattr(current_user, 'name'):
        return redirect(url_for('user.dashboard'))
    
    form = LoginForm()
    
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        password = form.password.data
        
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            flash(f'Welcome back, {user.name}!', 'success')
            return redirect(url_for('user.dashboard'))
        else:
            flash('Invalid email or password', 'danger')
    
    return render_template('login.html', form=form)

@user_bp.route('/dashboard')
@login_required
def dashboard():
    if not hasattr(current_user, 'name'):
        flash('Access denied', 'danger')
        return redirect(url_for('user.home'))
    
    recent_mockups = Mockup.query.filter_by(user_id=current_user.id).order_by(Mockup.created_at.desc()).limit(5).all()
    total_mockups = Mockup.query.filter_by(user_id=current_user.id).count()
    
    return render_template('dashboard.html', recent_mockups=recent_mockups, total_mockups=total_mockups)

@user_bp.route('/history')
@login_required
def history():
    if not hasattr(current_user, 'name'):
        flash('Access denied', 'danger')
        return redirect(url_for('user.home'))
    
    mockups = Mockup.query.filter_by(user_id=current_user.id).order_by(Mockup.created_at.desc()).all()
    return render_template('history.html', mockups=mockups)

@user_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out successfully', 'success')
    return redirect(url_for('user.home'))
