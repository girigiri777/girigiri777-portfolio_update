from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from models import Mockup, db
from forms import UploadForm
from utils.preprocess import preprocess_image
from utils.html_builder import generate_html_css
import os

predict_bp = Blueprint('predict', __name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@predict_bp.route('/upload', methods=['GET', 'POST'])
@login_required
def upload():
    if not hasattr(current_user, 'name'):
        flash('Access denied', 'danger')
        return redirect(url_for('user.home'))
    
    form = UploadForm()
    
    if form.validate_on_submit():
        file = form.mockup_image.data
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            timestamp = int(os.times().elapsed * 1000)
            unique_filename = f"{current_user.id}_{timestamp}_{filename}"
            
            upload_folder = 'static/uploads'
            os.makedirs(upload_folder, exist_ok=True)
            
            filepath = os.path.join(upload_folder, unique_filename)
            file.save(filepath)
            
            try:
                components_data = preprocess_image(filepath)
                html_code, css_code = generate_html_css(components_data)
                
                mockup = Mockup(
                    user_id=current_user.id,
                    image_name=unique_filename,
                    html_code=html_code,
                    css_code=css_code
                )
                db.session.add(mockup)
                db.session.commit()
                
                flash('Mockup processed successfully! Your HTML/CSS code is ready.', 'success')
                return redirect(url_for('predict.preview', mockup_id=mockup.id))
            
            except Exception as e:
                db.session.rollback()
                flash('Error processing mockup. Please try uploading a clearer image.', 'danger')
                if os.path.exists(filepath):
                    os.remove(filepath)
                return render_template('upload.html', form=form)
        else:
            flash('Invalid file type. Please upload PNG, JPG, or JPEG images only.', 'danger')
    
    return render_template('upload.html', form=form)

@predict_bp.route('/preview/<int:mockup_id>')
@login_required
def preview(mockup_id):
    if not hasattr(current_user, 'name'):
        flash('Access denied', 'danger')
        return redirect(url_for('user.home'))
    
    mockup = Mockup.query.get_or_404(mockup_id)
    
    if mockup.user_id != current_user.id:
        flash('Access denied. This mockup belongs to another user.', 'danger')
        return redirect(url_for('user.dashboard'))
    
    return render_template('preview.html', mockup=mockup)


