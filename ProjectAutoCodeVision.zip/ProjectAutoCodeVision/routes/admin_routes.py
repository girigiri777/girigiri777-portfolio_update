from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.security import check_password_hash
from models import Admin, User, Mockup, Dataset, ModelMetrics, db
from forms import AdminLoginForm
import plotly.graph_objs as go
import plotly

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

@admin_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated and hasattr(current_user, 'password_hash') and not hasattr(current_user, 'name'):
        return redirect(url_for('admin.dashboard'))
    
    form = AdminLoginForm()
    
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        password = form.password.data
        
        admin = Admin.query.filter_by(email=email).first()
        
        if admin and check_password_hash(admin.password_hash, password):
            login_user(admin)
            flash(f'Welcome Admin!', 'success')
            return redirect(url_for('admin.dashboard'))
        else:
            flash('Invalid admin credentials', 'danger')
    
    return render_template('admin_login.html', form=form)

@admin_bp.route('/dashboard')
@login_required
def dashboard():
    if hasattr(current_user, 'name'):
        flash('Access denied. Admin only.', 'danger')
        return redirect(url_for('user.home'))
    
    total_users = User.query.count()
    total_mockups = Mockup.query.count()
    total_datasets = Dataset.query.count()
    
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    recent_mockups = Mockup.query.order_by(Mockup.created_at.desc()).limit(5).all()
    
    metrics = ModelMetrics.query.order_by(ModelMetrics.trained_at.desc()).limit(10).all()
    
    chart_json = None
    if metrics:
        epochs = [m.epoch for m in reversed(metrics)]
        train_accs = [m.train_acc * 100 for m in reversed(metrics)]
        val_accs = [m.val_acc * 100 for m in reversed(metrics)]
        
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=epochs, y=train_accs, mode='lines+markers', name='Training Accuracy'))
        fig.add_trace(go.Scatter(x=epochs, y=val_accs, mode='lines+markers', name='Validation Accuracy'))
        fig.update_layout(
            title='Model Training Metrics',
            xaxis_title='Epoch',
            yaxis_title='Accuracy (%)',
            template='plotly_white'
        )
        chart_json = plotly.io.to_json(fig)
    
    return render_template('admin_dashboard.html', 
                         total_users=total_users, 
                         total_mockups=total_mockups,
                         total_datasets=total_datasets,
                         recent_users=recent_users,
                         recent_mockups=recent_mockups,
                         chart_json=chart_json)

@admin_bp.route('/users')
@login_required
def users():
    if hasattr(current_user, 'name'):
        flash('Access denied. Admin only.', 'danger')
        return redirect(url_for('user.home'))
    
    all_users = User.query.order_by(User.created_at.desc()).all()
    return render_template('admin_users.html', users=all_users)

@admin_bp.route('/delete_user/<int:user_id>')
@login_required
def delete_user(user_id):
    if hasattr(current_user, 'name'):
        flash('Access denied. Admin only.', 'danger')
        return redirect(url_for('user.home'))
    
    try:
        user = User.query.get_or_404(user_id)
        db.session.delete(user)
        db.session.commit()
        flash(f'User {user.email} has been deleted successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting user: {str(e)}', 'danger')
    
    return redirect(url_for('admin.users'))

@admin_bp.route('/delete_mockup/<int:mockup_id>')
@login_required
def delete_mockup(mockup_id):
    if hasattr(current_user, 'name'):
        flash('Access denied. Admin only.', 'danger')
        return redirect(url_for('user.home'))
    
    try:
        mockup = Mockup.query.get_or_404(mockup_id)
        db.session.delete(mockup)
        db.session.commit()
        flash('Mockup deleted successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error deleting mockup: {str(e)}', 'danger')
    
    return redirect(url_for('admin.dashboard'))

@admin_bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Admin logged out successfully', 'success')
    return redirect(url_for('admin.login'))
